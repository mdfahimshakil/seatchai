@extends('admin_layout.layout')

@section('content_section')

    <section class="section">
        <div class="section-body">
            <div class="row">
                <div class="col-12 col-md-12 col-lg-12">
                    <div class="card">
                        <div class="card-header">
                            <h4>Advertisement Post</h4>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="form-group col-sm-4">
                                    <label>Post For</label>
                                    <select name="student_condition" class="form-control">
                                        <option value="1" selected>Seat</option>
                                        <option value="2">Flat/House</option>
                                    </select>
                                </div>
                                <div class="form-group col-sm-4">
                                    <label>Rent Start Date</label>
                                    <input type="text" name="admission_date" class="datepicker form-control">
                                </div>
                                <div class="form-group col-sm-4">
                                    <label>Advertisement Date</label>
                                    <input type="text" id="rent_start_from_date"  name="rent_start_from_date" class="datepicker form-control">
                                </div>
                            </div>


                            <div class="row">
                                {{--                                <fieldset>--}}
                                {{--                                    <legend>Present Address:</legend>--}}

                                <div class="form-group col-sm-4">
                                    <label>Division</label>
                                    <select name="division_id" class="form-control select2">
                                        <option value="">Select One</option>
                                        <option value="1">Dhaka</option>
                                        <option value="2">Rajshahi</option>
                                    </select>
                                </div>
                                <div class="form-group col-sm-4">
                                    <label>District</label>
                                    <select name="district_id" class="form-control">
                                        <option value="">Select One</option>
                                        <option value="1">Dhaka</option>
                                        <option value="2">Rajshahi</option>
                                    </select>
                                </div>
                                <div class="form-group col-sm-4">
                                    <label>Thana</label>
                                    <select name="thana_id" class="form-control">
                                        <option value="">Select One</option>
                                        <option value="1">Dhaka</option>
                                        <option value="2">Rajshahi</option>
                                    </select>
                                </div>
                            </div>

                            <div class="row">
                                <div class="form-group col-sm-4">
                                    <label>Email</label>
                                    <input type="email" name="email" class="form-control">
                                </div>
                                <div class="form-group col-sm-4">
                                    <label>Renter Mobile</label>
                                    <input type="text" name="student_mobile" class="form-control">
                                </div>
                                <div class="form-group col-sm-4">
                                    <label>Emergency Mobile</label>
                                    <input type="text" name="emergency_mobile" class="form-control">
                                </div>
                            </div>
                                <div class="row">
                                    <div class="form-group col-sm-4">
                                        <label>Department</label>
                                        <select name="district_id" class="form-control">
                                            <option value="">Select One</option>
                                            <option value="1">Textile Engineer</option>
                                            <option value="2">Textile Management & business</option>
                                            <option value="2">Textile Chemical</option>
                                        </select>
                                    </div>
                                    <div class="form-group col-sm-4">
                                        <label>Post Office</label>
                                        <input type="text" name="post" class="form-control">
                                    </div>
                                    <div class="form-group col-sm-4">
                                        <label>Address</label>
                                        <input type="text" name="address" class="form-control">
                                    </div>

                               </div>

                                <div class="row">
                                    <div class="card-footer text-right">
                                        <button class="btn btn-primary mr-1" type="submit">Submit</button>
                                        <button class="btn btn-secondary" type="reset">Reset</button>
                                    </div>
                               </div>

                                </fieldset>
                            </div>

                        </div>
                    </div>
                </div>
            </div>

        <!-- start data table -->
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <h4>Renter List</h4>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-striped table-hover" id="save-stage" style="width:100%;">
                                        <thead>
                                        <tr>
                                            <th>Name</th>
                                            <th>Renter ID</th>
                                            <th>Department</th>
                                            <th>Hall</th>
                                            <th>Mobile</th>
                                            <th>Year</th>
                                            <th>Batch</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <tr>
                                            <td>Meherajul Hoque Tahin </td>
                                            <td>201912067</td>
                                            <td>FE</td>
                                            <td>G.M.A.G Osmani  Hall </td>
                                            <td>01792386867</td>
                                            <td>2019</td>
                                            <td>45</td>
                                        </tr>
                                        <tr>
                                            <td>Mahmudul Kabir Rafi </td>
                                            <td>201911024</td>
                                            <td>YE</td>
                                            <td>G.M.A.G Osmani  Hall </td>
                                            <td>01885208550</td>
                                            <td>2019</td>
                                            <td>43</td>
                                        </tr>
                                        <tr>
                                            <td>Joy Paul</td>
                                            <td>201912006</td>
                                            <td>FE</td>
                                            <td>G.M.A.G Osmani  Hall </td>
                                            <td>01837124275</td>
                                            <td>2019</td>
                                            <td>45</td>
                                        </tr>
                                        <tr>
                                            <td>Md Jamal Uddin </td>
                                            <td>201718037</td>
                                            <td>TMDM</td>
                                            <td>G.M.A.G Osmani  Hall </td>
                                            <td>01764890737</td>
                                            <td>2017</td>
                                            <td>43</td>
                                        </tr>

                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
        </div>
    </section>

@endsection

<footer class="main-footer">
    <div class="footer-left">
        <a href="#">Developed By KANFATECH</a></a>
    </div>
    <div class="footer-right">
    </div>
</footer>

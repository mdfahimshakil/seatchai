@extends('admin_layout.layout')

@section('content_section')

    <section class="section">
        <div class="section-body">
            <div class="row">
                <div class="col-12 col-md-12 col-lg-12">
                    <div class="card">
                        <div class="card-header">
                            <h4>House owner profile entry</h4>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="form-group col-sm-4">
                                    <label>House owner ID</label>
                                    <input type="text" name="teacher_id" class="form-control">
                                </div>
                                <div class="form-group col-sm-4">
                                    <label>House owner condition</label>
                                    <select name="teacher_condition" class="form-control">
                                        {{--<option value="">Select One</option>--}}
                                        <option value="1" selected>Regular</option>
                                        <option value="2">IRegular</option>
                                        <option value="3">Part time</option>
                                    </select>
                                </div>
                                <div class="form-group col-sm-4">
                                    <label>Job joining Date</label>
                                    <input type="text" name="admission_date" class="datepicker form-control">
                                </div>
                            </div>
                            <div class="row">
                                <div class="form-group col-sm-4">
                                    <label>House owner DOB</label>
                                    <input type="text" name="dob" class="datepicker form-control">
                                </div>
                                <div class="form-group col-sm-4">
                                    <label>House owner name</label>
                                    <input type="text" name="teacher_name" class="form-control">
                                </div>
                                <div class="form-group col-sm-4">
                                    <label>Father's name</label>
                                    <input type="text" name="fathers_name" class="form-control">
                                </div>
                            </div>
                            <div class="row">
                                <div class="form-group col-sm-4">
                                    <label>Fathers Mobile</label>
                                    <input type="text" name="fathers_mobile" class="form-control">
                                </div>
                                <div class="form-group col-sm-4">
                                    <label>Mothers name</label>
                                    <input type="text" name="mothers_name" class="form-control">
                                </div>
                                <div class="form-group col-sm-4">
                                    <label>Mothers Mobile</label>
                                    <input type="text" name="mothers_mobile" class="form-control">
                                </div>
                            </div>
                            <div class="row">
                                <div class="form-group col-sm-4">
                                    <label>Email</label>
                                    <input type="email" name="email" class="form-control">
                                </div>
                                <div class="form-group col-sm-4">
                                    <label>House owner Mobile</label>
                                    <input type="text" name="student_mobile" class="form-control">
                                </div>
                                <div class="form-group col-sm-4">
                                    <label>Emergency Mobile</label>
                                    <input type="text" name="emergency_mobile" class="form-control">
                                </div>
                            </div>
                            <div class="row">
{{--                                <fieldset>--}}
{{--                                    <legend>Present Address:</legend>--}}

                                    <div class="form-group col-sm-4">
                                        <label>Division</label>
                                        <select name="division_id" class="form-control select2">
                                            <option value="">Select One</option>
                                            <option value="1">Dhaka</option>
                                            <option value="2">Rajshahi</option>
                                        </select>
                                    </div>
                                    <div class="form-group col-sm-4">
                                        <label>District</label>
                                        <select name="district_id" class="form-control">
                                            <option value="">Select One</option>
                                            <option value="1">Dhaka</option>
                                            <option value="2">Rajshahi</option>
                                        </select>
                                    </div>
                                    <div class="form-group col-sm-4">
                                        <label>Thana</label>
                                        <select name="thana_id" class="form-control">
                                            <option value="">Select One</option>
                                            <option value="1">Dhaka</option>
                                            <option value="2">Rajshahi</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="form-group col-sm-4">
                                        <label>Department</label>
                                        <select name="district_id" class="form-control">
                                            <option value="">Select One</option>
                                            <option value="1">Textile Engineer</option>
                                            <option value="2">Textile Management & business</option>
                                            <option value="2">Textile Chemical</option>
                                        </select>
                                    </div>
                                    <div class="form-group col-sm-4">
                                        <label>Post Office</label>
                                        <input type="text" name="post" class="form-control">
                                    </div>
                                    <div class="form-group col-sm-4">
                                        <label>Address</label>
                                        <input type="text" name="address" class="form-control">
                                    </div>

                               </div>

                                <div class="row">
                                    <div class="card-footer text-right">
                                        <button class="btn btn-primary mr-1" type="submit">Submit</button>
                                        <button class="btn btn-secondary" type="reset">Reset</button>
                                    </div>
                               </div>

                                </fieldset>
                            </div>

                        </div>
                    </div>

                </div>
            </div>

        <!-- start data table -->
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h4>House owner List</h4>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped table-hover" id="save-stage" style="width:100%;">
                                <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>House owner ID</th>
                                    <th>Designation</th>
                                    <th>Department</th>
                                    <th>Mobile</th>
                                    <th>Joining Year</th>

                                </tr>
                                </thead>
                                <tbody>
                                <tr>
                                    <td>Jawad </td>
                                    <td>201912067</td>
                                    <td>Assistant. Professor</td>
                                    <td>FE</td>
                                    <td>01792386867</td>
                                    <td>2019</td>
                                </tr>
                                <tr>
                                    <td>K.M Mahmudul </td>
                                    <td>201911024</td>
                                    <td>Assistant. Professor</td>
                                    <td>YE</td>
                                    <td>01885208550</td>
                                    <td>2019</td>
                                </tr>
                                <tr>
                                    <td>Joy Paul</td>
                                    <td>201912006</td>
                                    <td>Sr. Lecturer</td>
                                    <td>FE</td>
                                    <td>01837124275</td>
                                    <td>2019</td>

                                </tr>
                                <tr>
                                    <td>Md Jamal Uddin </td>
                                    <td>201718037</td>
                                    <td>Professor</td>
                                    <td>TMDM</td>
                                    <td>01764890737</td>
                                    <td>2017</td>
                                </tr>

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--end data table -->
        </div>
    </section>

@endsection

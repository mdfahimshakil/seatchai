@extends('admin_layout.layout')

@section('content_section')

    <section class="section">
        <div class="section-body">
            <div class="row">
                <div class="col-12 col-md-12 col-lg-12">
                    <div class="card">
                        <div class="card-header">
                            <h4>Dahsboard</h4>
                        </div>
                        <div class="card-body">


                        </div>
                    </div>

                </div>

            </div>
        </div>
    </section>

@endsection

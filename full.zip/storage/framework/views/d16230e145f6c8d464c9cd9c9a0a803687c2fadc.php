<footer class="main-footer">
    <div class="footer-left">
        <a href="templateshub.net">Templateshub</a></a>
    </div>
    <div class="footer-right">
    </div>
</footer>
<?php /**PATH C:\xampp\htdocs\seatchai\resources\views/layout/footer.blade.php ENDPATH**/ ?>
<!DOCTYPE html>
<html lang="en">
<!-- forms-advanced-form.html  21 Nov 2019 03:54:41 GMT -->
<head>
    <meta charset="UTF-8">
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no" name="viewport">
    <meta name="csrf-token" id="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>Seatchai</title>
    <!-- General CSS Files -->
    <link rel="stylesheet" href="admin_assets/css/app.min.css">

    <link rel="stylesheet" href="admin_assets/bundles/datatables/datatables.min.css">
    <link rel="stylesheet" href="admin_assets/bundles/datatables/DataTables-1.10.16/css/dataTables.bootstrap4.min.css">

    <link rel="stylesheet" href="admin_assets/bundles/bootstrap-daterangepicker/daterangepicker.css">
    <link rel="stylesheet" href="admin_assets/bundles/bootstrap-colorpicker/dist/css/bootstrap-colorpicker.min.css">
    <link rel="stylesheet" href="admin_assets/bundles/select2/dist/css/select2.min.css">
    <link rel="stylesheet" href="admin_assets/bundles/jquery-selectric/selectric.css">
    <link rel="stylesheet" href="admin_assets/bundles/bootstrap-timepicker/css/bootstrap-timepicker.min.css">
    <link rel="stylesheet" href="admin_assets/bundles/bootstrap-tagsinput/dist/bootstrap-tagsinput.css">
    <!-- Template CSS -->
    <link rel="stylesheet" href="admin_assets/css/style.css">
    <link rel="stylesheet" href="admin_assets/css/components.css">
    <!-- Custom style CSS -->
    <link rel="stylesheet" href="admin_assets/css/custom.css">
    <link rel='shortcut icon' type='image/x-icon' href='admin_assets/img/favicon.ico' />
</head>

<body>
<div class="loader"></div>
<div id="app">
    <div class="main-wrapper main-wrapper-1">
        <!-- Top Menu -->
        <?php echo $__env->make('admin_layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('admin_layout.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- Main Content -->
        <div class="main-content">
            <?php echo $__env->yieldContent('content_section'); ?>;
            <?php echo $__env->make('admin_layout.setting_sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <?php echo $__env->make('admin_layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</div>
<!-- General JS Scripts -->
<script src="admin_assets/js/app.min.js"></script>
<!-- JS Libraies -->
<script src="admin_assets/bundles/cleave-js/dist/cleave.min.js"></script>
<script src="admin_assets/bundles/cleave-js/dist/addons/cleave-phone.us.js"></script>
<script src="admin_assets/bundles/jquery-pwstrength/jquery.pwstrength.min.js"></script>
<script src="admin_assets/bundles/bootstrap-daterangepicker/daterangepicker.js"></script>
<script src="admin_assets/bundles/bootstrap-colorpicker/dist/js/bootstrap-colorpicker.min.js"></script>
<script src="admin_assets/bundles/bootstrap-timepicker/js/bootstrap-timepicker.min.js"></script>
<script src="admin_assets/bundles/bootstrap-tagsinput/dist/bootstrap-tagsinput.min.js"></script>
<script src="admin_assets/bundles/select2/dist/js/select2.full.min.js"></script>
<script src="admin_assets/bundles/jquery-selectric/jquery.selectric.min.js"></script>

<script src="admin_assets/bundles/datatables/datatables.min.js"></script>
<script src="admin_assets/bundles/datatables/DataTables-1.10.16/js/dataTables.bootstrap4.min.js"></script>
<script src="admin_assets/bundles/jquery-ui/jquery-ui.min.js"></script>
<!-- Page Specific JS File -->
<script src="admin_assets/js/page/datatables.js"></script>
<!-- Page Specific JS File -->
<script src="admin_assets/js/page/forms-advanced-forms.js"></script>
<!-- Template JS File -->
<script src="admin_assets/js/scripts.js"></script>
<!-- Custom JS File -->
<script src="admin_assets/js/custom.js"></script>
</body>
<script>
    /*$(".choose-theme li .clickIt").click(function(){
    alert(9);
    });*/
</script>

<!-- forms-advanced-form.html  21 Nov 2019 03:55:08 GMT -->
</html>
<?php /**PATH C:\xampp\htdocs\seatchai\resources\views/admin_layout/layout.blade.php ENDPATH**/ ?>
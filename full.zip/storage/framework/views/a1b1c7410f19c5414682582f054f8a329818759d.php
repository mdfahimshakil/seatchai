<div class="main-sidebar sidebar-style-2">
    <aside id="sidebar-wrapper">
        <div class="sidebar-brand">
            <a href="#">

                <span
                    class="logo-name">Seatchai</span>
            </a>
        </div>
        <ul class="sidebar-menu">
            
            <li class="dropdown">
                <a href="/dashboard" class="nav-link"><i data-feather="monitor"></i><span>Dashboard</span></a>
            </li>
           
            <li class="dropdown">
                <a href="#" class="menu-toggle nav-link has-dropdown"><i
                        data-feather="chevrons-down"></i><span>Entry</span></a>
                <ul class="dropdown-menu">
                    <li><a href="adv-post">Advertisement Post</a></li>
                    <li><a href="student-reg">Renter Registration</a></li>
                    <li><a href="teacher-reg">House owner Registration</a></li>
                    <li class="dropdown">
                        <a href="#" class="has-dropdown">Setup</a>
                        <ul class="dropdown-menu">
                            <li><a href="hall-reg">Building</a></li>
                            <li><a href="hall-reg">House or flat</a></li>
                            <li><a href="hall-reg">Seat</a></li>
                            
                        </ul>
                    </li>
                </ul>
            </li>
        </ul>
    </aside>
</div>
<?php /**PATH C:\xampp\htdocs\seatchai\resources\views/admin_layout/sidebar.blade.php ENDPATH**/ ?>
<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Model\UserRegister;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Route;
use DB;

class UserController extends Controller
{
    private $user;

    public function __construct()
    {
        $this->user = new UserRegister();
    }

    public function index() {
        return view('admin_layout.login');
    }

    public function authorization(Request $request) {
        try {
            $password = $request->get('password');
            $email = $request->get('email');
            $data = $this->user->where('user_email', '=', $email)->where('user_enc_pass', '=', $password)->first();

            if($data && $data["user_id"]) {
                if($data["user_status"] ==1){
                    /*Auth::login($this->user);
                    if ($this->user->need_pass_reset == YesNoFlag::YES)*/
                    //Auth::login($data["user_id"]);
                    return Redirect::route("auth-index",["status_code"=>1,"status_msg"=>"Login Successful"]);
                    //return \Redirect::route("auth-layout",["status_code"=>1,"status_msg"=>"Login Successful"]);
                    //return redirect()->route("auth-layout",["status_code"=>1,"status_msg"=>"Login Successful"]);
                }else{
                    return Redirect::route("auth-logout",["status_code"=>99,"status_msg"=>"User is Inactive"]);
                    //return \Redirect::route("auth-logout",["status_code"=>99,"status_msg"=>"User is Inactive"]);
                    //return redirect()->route("auth-logout",["status_code"=>99,"status_msg"=>"User is Inactive"]);
                }
            }
            else{
                return Redirect::route("auth-logout",["status_code"=>99,"status_msg"=>"Wrong User or Password"]);
                //return redirect()->route("auth-logout",["status_code"=>99,"status_msg"=>"Wrong User or Password"]);
            }
           /* $validator = \Illuminate\Support\Facades\Validator::make([], []);
            $validator->getMessageBag()->add('error', $mappedParams['o_status_message']);
            return Redirect::back()->withErrors($validator)->withInput();*/
            //return \Redirect::back()->withInput();
            exit();
        }
        catch (\Exception $e) {
          /*  $error = \Illuminate\Validation\ValidationException::withMessages([
                'error' => [$e->getMessage()]
            ]);
            throw $error;*/
            echo $e->getMessage();
            exit();
        }
    }

	public function authorizationApi(Request $request) {
        try {
            $password = $request->get('password');
            $email = $request->get('email');
            $what_operation = $request->get('what_operation'); //
            
			/*
			$data = DB::select("select * user_email from user_register 
				where user_email = '$email' and
				user_enc_pass = '$password' limit 1");
			*/	
			$data = $this->user->where('user_email', '=', $email)->where('user_enc_pass', '=', $password)->first();

			if($data && $what_operation == 'login') {
                if($data["user_status"] ==1){
                    return response()->json(["status_code"=>1,"status_msg"=>"Login Successful","data"=>$data]);
                   }else{
                    return response()->json(["status_code"=>99,"status_msg"=>"User is Inactive","data"=>$data]);
                }
            }else if($data && $what_operation == 'search_empty_seat_list'){
				 $start = $request->get('start');
				 $end = $request->get('end')? $request->get('end') : $request->get('start');
				 $thana = $request->get('thana');

				$result_data = DB::select("SELECT * FROM seat s,`building` b 
				where s.building_id = b.building_id
				and b.active_yn ='Y' 
				and s.active_yn ='Y' 
				and b.thana_id = $thana
				 and s.advertise_start_date BETWEEN '$start' and '$end'");
				
				return response()->json(["status_code"=>1,"status_msg"=>"Login Successful","data"=>$data,"result_data"=>$result_data]);
                   
			}else if($data && $what_operation == 'search_empty_seat_all_thana_list'){
				 $start = $request->get('start');
				 $end = $request->get('end')? $request->get('end') : $request->get('start');

				$result_data = DB::select("SELECT * FROM seat s,`building` b 
				where s.building_id = b.building_id
				and b.active_yn ='Y' 
				and s.active_yn ='Y' 
				and s.advertise_start_date BETWEEN $start and '$end'");
				
				return response()->json(["status_code"=>1,"status_msg"=>"Login Successful","data"=>$data,"result_data"=>$result_data]);
                   
			}else if($data && $what_operation == 'search_empty_all_seat_list'){
				$result_data = DB::select("SELECT * FROM seat s,`building` b 
				where s.building_id = b.building_id
				and b.active_yn ='Y' 
				and s.active_yn ='Y'");
				
				return response()->json(["status_code"=>1,"status_msg"=>"Login Successful","data"=>$data,"result_data"=>$result_data]);
                
			}else if($data && $what_operation == 'search_individual_empty_seat_details'){
				 $seat = $request->get('seat');

				$result_data = DB::select("SELECT * FROM seat s,`building` b 
				where s.building_id = b.building_id
				and b.active_yn ='Y' 
				and s.active_yn ='Y' 
				and s.seat_id = $seat");
 
				return response()->json(["status_code"=>1,"status_msg"=>"Login Successful","data"=>$data,"result_data"=>$result_data]);
                   
			}
            else{
                   return response()->json(["status_code"=>99,"status_msg"=>"Wrong Username or Password","data"=>array()]);
            }
            exit();
        }
        catch (\Exception $e) {
            echo $e->getMessage();
            exit();
        }
    }
	
    public function logout(Request $request) {
        Auth::logout();
        return redirect('/');
    }
}

<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class UserRegister extends Model
{
    protected $table = "user_register";
    protected $primaryKey = "user_id";
}

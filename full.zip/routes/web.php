<?php

use Illuminate\Support\Facades\Route;

Route::group(['middleware' => ['web']], function () {
    Route::get('/', 'UserController@index')->name('login');
    Route::get('auth-layout/{status_code?}/{status_msg?}', 'HomeController@dashboard')->name('auth-index'); //admin_index
    Route::get('auth-layout', 'HomeController@dashboard')->name('auth-index'); //admin_index
    Route::get('dashboard', 'HomeController@dashboard')->name('dashboard');

    Route::get('adv-post', 'AdvertisementPostController@index')->name('adv_post_index');
    Route::get('student-reg', 'StudentRegController@index')->name('student_index');
    Route::post('student-reg', 'StudentRegController@student_reg')->name('student_reg');

    Route::get('teacher-reg', 'TeacherRegController@index')->name('teacher_index');
    Route::post('teacher-reg', 'TeacherRegController@teacher_reg')->name('teacher_reg');

    //Setup
    Route::get('hall-reg', 'HallRegController@index')->name('hall_index');
   // Route::post('hall-reg', 'HallRegController@hall_reg')->name('hall_reg');

    //Ajax
});
Route::get('auth-login', 'HomeController@admin_login')->name('auth-login');
Route::get('auth-logout', 'HomeController@admin_logout')->name('auth-logout');
Route::get('layout', 'HomeController@index');
Route::get('header', 'HomeController@header');

Route::post('auth-authorization', 'UserController@authorization')->name('auth-authorization');
//Route::post('/authorization/login', 'Auth\LoginController@authorization')->name('authorization.login');
